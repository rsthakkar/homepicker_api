<?php $__env->startSection('content'); ?>
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		    <?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul type="none">
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
		<div>
	 		<form action="add_city">
		 	 	<table class="table">
		 	 		<tr>
		 	 			<td align="right">Add City:</td>
		 	 			<td><input type="text" autocomplete="off" class="form-control" name="city" required></td>
		 	 			<td>
		 	 				<select name="state_id" class="form-control">
		 	 					<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	 					<option value="<?php echo e($state->id); ?>"><?php echo e($state->state_name); ?></option>
		 	 					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	 				</select>
		 	 			</td>
		 	 			<td><button type="submit" class="btn btn-primary">Add</button></td>
		 	 		</tr>
		 	 	</table>
	 	 	</form>
	 	</div>

			<div class="blank-page">
				<table class="table">
					<thead>
						<tr>
							<td>ID</td>
							<td>City</td>
							<td>State</td>
							<td>New Name</td>
							<td>Update</td>
							<td>Delete</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<?php if($states->count()>0): ?>
							<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($city->id); ?></td>
								<td><?php echo e($city->city); ?></td>
								<form action="update_city">
								<td>
									<select class="form-control" name="state_id">
										<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($state->id); ?>" <?php if($state->id == $city->state_id): ?>  selected="selected"  <?php endif; ?>>
												<?php echo e($state->state_name); ?>

											</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
									<td><input class="form-control" value="<?php echo e($city->city); ?>" required="" autocomplete="off" type="text" name="city">
										<input type="hidden" value="<?php echo e($city->id); ?>" name="id"></td>
									<td><button type="submit" class="btn btn-primary">Update</button></td>
								</form>
								<td><a class="btn btn-danger" href="delete_city/<?php echo e($city->id); ?>">Delete</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
							<tr>
								<td>No Data</td>
							</tr>
							<?php endif; ?>
						</tr>
					</tbody>
				</table>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->

		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>