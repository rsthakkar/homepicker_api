<?php

namespace App\Http\Controllers\API;
use App\Loginuser;
use App\Member;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth; 

class UserController extends Controller
{

	public $successStatus = 200;
    //
	public function login(){
       if(Auth::attempt(['mobile_no' => request('monumber'), 'password' => request('password')])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('random')-> accessToken; 
       	die('asd');
            return response()->json($success, 200); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }

    /** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function register(Request $request) 
    { 
  //       $validator = Validator::make($request->all(), [ 
  //           'firstname' => 'required', 
  //           'lastname'=> 'required',
  //           'mobile_no' => 'required', 
  //           'email' => 'required|email', 
  //           'password' => 'required', 
  //           'c_password' => 'required|same:password',
  //           'address' => 'required', 
  //           'city_id' => 'required',  
  //       ]);
		// if ($validator->fails()) { 
		//             return response()->json(['error'=>$validator->errors()], 401);            
		//         } 
		 $input = $request->all();

		 $input['category_id']=1;
		        //$input['dob']="2012-01-01"; 
		 //return response()->json([$input], $this-> successStatus);  
		        $input['password'] = bcrypt($input['password']);
		        Loginuser::create([
		        	'mobile_no'=>$input['mobile_no'],
		        	'password'=>$input['password'],
		        ]);

		        $user=Loginuser::select('id')
		        		->where('mobile_no',$input['mobile_no'])
		        		->first();
		        		
		        		

		        Member::create([
		        	'login_id'=>$user['id'],
		        	'firstname'=>$input['firstname'],
		        	'lastname'=>$input['lastname'],
		        	'gender'=>$input['gender'],
		        	'date_of_birth'=>$input['dob'],
		        	'email'=>$input['email'],
		        	'category_id'=>$input['category_id'],
		        	'address'=>$input['address'],
		        	'city_id'=>$input['city_id'],
		        	'org_name'=>$input['org_name'],

		        ]);



		        //$success['token'] =  $user->createToken('MyApp')-> accessToken; 
		        //$success['name'] =  $user->name;
			return response()->json(['status'=>'success'], $this-> successStatus); 
		    }
		/** 
		     * details api 
		     * 
		     * @return \Illuminate\Http\Response 
		     */ 
		public function details() 
	    { 
	        $user = Auth::user(); 
	        return response()->json(['data' => $user], $this-> successStatus); 
	    } 


		public function logout()
		{ 
		    if (Auth::check()) {
		       Auth::user()->AauthAcessToken()->delete();
		    }
		}
}
