<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Area;
use App\Http\Controllers\Controller;


class AreaController extends Controller
{
	public function get_areas($city_id){
		$areas=Area::where("city_id","=",$city_id)->get();
		$count=$areas->count();
	
		if($areas->count()>0)
			return response()->json(["data"=>$areas,"count"=>$count],200);
		else
			return response()->json(["msg"=>"no data available"],401);
	}

	public function insert_area(Request $request){
		
	}    
}
