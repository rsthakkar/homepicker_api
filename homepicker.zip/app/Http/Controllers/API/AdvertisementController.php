<?php

namespace App\Http\Controllers\API;

use App\Member;
use App\Advertisement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;


class AdvertisementController extends Controller
{
    public function insert_ad(Request $request){
    	try{
	    	$user = Auth::user();
	    	$input = $request->all();
	    	$member= Member::where('login_id','=',$user->id)->firstorFail();
	    	$input['member_id']=$member->id;
	    	
	    	$validator = Validator::make($input, [
	           		"member_id"=>"required",
		    	  	"type"=>"required",
		    	  	"address"=>"required",
		    	  	"area_id"=>"required",
		    	  	"status"=>"required",
		    	  	"paymentStatus"=>"required",
		    	 	"extra_notes"=>"required",
		    	 	"show_contact_details"=>"required",
		    	 	"addTitle"=>"required"
	        ]);
	        if ($validator->fails()) {
	            return response()->json($validator->messages(),401);
	        }
	        else{
	        	Advertisement::create([
		    	 	"member_id"=>"",
		    	 	"type"=>"",
		    	 	"address"=>"",
		    	 	"area_id"=>"",
		    	 	"status"=>"",
		    	 	"paymentStatus"=>"",
		    	 	"extra_notes"=>"",
		    	 	"show_contact_details"=>"",
		    	 	"addTitle"=>""
		    	]);
	        }
	    }
	    catch (\Exception $e) {
   	 		return response()->json([$e->getMessage()]);
		}
	}
}
