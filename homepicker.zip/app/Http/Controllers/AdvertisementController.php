<?php

namespace App\Http\Controllers;

use App\Advertisement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 


class AdvertisementController extends Controller
{
    //
    
}
