<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdFacility extends Model
{
    //
}
