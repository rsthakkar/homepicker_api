<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdAmenitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ad_amenities', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('amenities_id');
            $table->foreign('amenities_id')->references('id')->on('amenities')->onDelete('cascade');
            $table->unsignedInteger('ad_id');
            $table->foreign('ad_id')->references('id')->on('advertisements')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ad_amenities');
    }
}
