
@extends('admin.admin_layout')
@section('content')
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		    
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page">
				<table class="table">
					<thead>
						<tr>
							<td>ID</td>
							<td>State</td>
							<td>StateID</td>
							<td>New Name</td>
							<td>Update</td>
							<td>Delete</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>State</td>
							<td>StateID</td>
							<td>New Name</td>
							<td>Update</td>
							<td>Delete</td>
						</tr>
					</tbody>
				</table>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->

		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
 @endsection

